package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class HomeActivity extends AppCompatActivity {

    ImageButton tabPron,tabLigas,tabRecom, ajustesIcon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        tabPron = findViewById(R.id.tabPron);
        tabLigas = findViewById(R.id.tabLigas);
        tabRecom = findViewById(R.id.tabRecom);
        ajustesIcon = findViewById(R.id.ajustesIcon);

        tabPron.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeActivity.this, PronActivity.class);
                startActivity(i);
            }
        });
        tabLigas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeActivity.this, LigasActivity.class);
                startActivity(i);
            }
        });
        tabRecom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeActivity.this, RecomActivity.class);
                startActivity(i);
            }
        });

    }
}
