package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class PronActivity extends AppCompatActivity {
    Button botonBack;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pron_activity);
        botonBack = (Button) findViewById(R.id.botonRetroceder);
        botonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PronActivity.this, HomeActivity.class);
                startActivity(i);
            }
        });
    }
}
