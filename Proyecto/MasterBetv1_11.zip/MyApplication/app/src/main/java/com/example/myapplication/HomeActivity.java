package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    Button tabPron,tabLigas,tabRecom;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        tabPron = (Button) findViewById(R.id.tabPron);
        tabLigas = (Button) findViewById(R.id.tabLigas);
        tabRecom = (Button) findViewById(R.id.tabRecom);

        tabPron.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeActivity.this, PronActivity.class);
                startActivity(i);
            }
        });
        tabLigas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeActivity.this, LigasActivity.class);
                startActivity(i);
            }
        });
        tabRecom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(HomeActivity.this, RecomActivity.class);
                startActivity(i);
            }
        });
    }
}
