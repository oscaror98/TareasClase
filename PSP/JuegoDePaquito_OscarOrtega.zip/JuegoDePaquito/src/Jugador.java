public class Jugador {
    private int dorsal;
    private char alive ;

    public Jugador(int dorsal) {
        this.alive = 'S';
        this.dorsal = dorsal;
    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public char getAlive() {
        return alive;
    }

    public void setAlive(char alive) {
        this.alive = alive;
    }
    public void setDeath() {
        this.alive = 'N';
    }
}
