import java.util.ArrayList;
import java.util.Random;

public class Juego {

    private String name;
    private int muertos;
    ArrayList<Jugador> lista_jugadores = new ArrayList<>();

    public Juego(ArrayList<Jugador> list) {
        lista_jugadores = list;
        muertos = 0;
    }

    public void ninya(int numJuego){
        System.out.println("Juego " + numJuego + " de 5");
        try {
            Thread.sleep(1000);
            System.out.println("Luz verde");
            Thread.sleep(1000);
            System.out.println("ya puedes correr");
            Thread.sleep(1000);
            System.out.println("y parar!");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void eliminar(){

        Random r = new Random();

        int deathPlayers = (int)(r.nextDouble()*(lista_jugadores.size()-muertos)+1);
        System.out.println("De "+ (lista_jugadores.size()-muertos) +", vamos a eliminar a " + deathPlayers+ " concursantes");

        for(int i = 0; i < deathPlayers; i++){
            int idToKill = (int)(r.nextDouble()*455+1);
            if(lista_jugadores.get(idToKill).getAlive() == 'S'){
                lista_jugadores.get(idToKill).setDeath();
                muertos ++;
                System.out.println("Jugador " + idToKill + ": ELIMINADO");
            }else{
                i--;
            }
        }

        if(muertos <= 0)
            System.out.println("No quedan supervivientes");
        else
        System.out.println("Quedan vivos " + (lista_jugadores.size()-muertos));
    }

}
