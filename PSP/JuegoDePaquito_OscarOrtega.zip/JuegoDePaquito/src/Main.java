import java.util.ArrayList;

/**
 * Juego de Paquito
 * @author oscarortega
 * @version 1.0
 */
public class Main {
    public static void main(String[] args) {
        ArrayList<Jugador> lista_jugadores = new ArrayList<>();

        for(int i = 1; i <= 456; i++){
            Jugador j = new Jugador(i);
            lista_jugadores.add(j);
        }

        Juego calamar = new Juego(lista_jugadores);
        Hilo h1 = new Hilo(calamar,"ninya");
        Hilo h2 = new Hilo(calamar,"eliminar");

        h1.start();
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        h2.start();

        try{
            h1.join();
            h2.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        System.err.println("---------- FIN DEL JUEGO ----------");
    }
}