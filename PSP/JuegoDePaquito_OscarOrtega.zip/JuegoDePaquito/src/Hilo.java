public class Hilo extends Thread {

    private Juego game;
    private String orden;
    public Hilo(Juego game , String order) {
        super();
        this.game = game;
        orden = order;
    }

    @Override
    public void run() {
        super.run();

        for(int i = 1; i <= 5 ; i++) {
                    synchronized (game){

                    if(orden.contains("ninya")) {
                        game.ninya(i);
                        try {
                            Thread.sleep(1000);
                            game.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }else{
                        game.notify();

                    }

                    if(orden.contains("eliminar")) {
                        try {
                            game.eliminar();
                            game.wait();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }else{
                        game.notify();

                    } // If eliminar

                } // Synchronized Ends
         } // For Ends
    }
}
