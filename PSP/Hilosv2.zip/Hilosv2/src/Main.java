import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> coches = createCars();
        startRace(coches);
    }

    public static ArrayList<String> createCars(){
        ArrayList<String> listaCoches = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca numeros de coches a competir: ");
        int coches = sc.nextInt();
        sc.nextLine();
        for(int i = 1; i <= coches; i++){
            System.out.println("Introduzca marca del coche " + i + ": ");
            String name = sc.nextLine();
            listaCoches.add(name.toUpperCase());
            System.out.println("Coche creado: " + name + "(" + i + ")");
        }
        System.out.println("Que comience la carrera!");
        return listaCoches;
    }

    public static void startRace(ArrayList<String> listaCoches){
        Runnable regulador = () -> {
            Random r = new Random();
            int distancia = 0;
            while(distancia < 500) {
                distancia += r.nextInt(100) + 1;
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println(Thread.currentThread().getName() + " lleva recorrido " + distancia + "km!");
            }
            System.out.println("------------------------------------------------------");
            System.out.println("El " + Thread.currentThread().getName() + " ha finalizado al recorrer " + distancia + "km.");
        };

        ThreadGroup carrera = new ThreadGroup("Hilo Carrera");

        Thread coche1 = new Thread(carrera, regulador, listaCoches.get(0));
        Thread coche2 = new Thread(carrera, regulador, listaCoches.get(1));
        Thread coche3 = new Thread(carrera, regulador, listaCoches.get(2));

        coche1.start();
        coche2.start();
        coche3.start();

    }
}