package com.example.asteroi2;

public class AlmacenaPuntuaciones {
}
