package com.example.asteroi2;

import java.util.List;

/**
 * Paso 12. C
 */
public interface AlmacenaPuntuaciones {
    public void guardarPuntuacion(int puntos, String nombre, long fecha);
    public List<String> listaPuntuaciones(int cantidad);
}
