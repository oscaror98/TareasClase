package com.example.asteroi2;

import android.app.Application;
import android.content.SharedPreferences;

/**
 * Paso 11 . A
 */
public class Aplicacion extends Application {
    private int saldo;
    @Override
    public void onCreate(){
    super.onCreate();
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        saldo = pref.getInt("saldo_inicial",-1);
    }
    public int getSaldo(){
        return saldo;
    }
    public void setSaldo(int saldo){
        this.saldo = saldo;
    }

}
